"""
Golf Swing AI - FastAPI Web Service
Physics-based golf swing plane classification
"""

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import tempfile
import os
import sys
from pathlib import Path

# Add current directory to path for imports
sys.path.append(str(Path(__file__).parent))

from predict_physics_based import predict_with_physics_model

app = FastAPI(
    title="Golf Swing AI",
    description="Physics-based golf swing plane classification",
    version="1.0.0"
)

@app.get("/")
async def root():
    return {
        "message": "Golf Swing AI - Physics-based swing plane classification",
        "version": "1.0.0",
        "model": "Physics-based Neural Network",
        "classes": ["on_plane", "too_steep", "too_flat"]
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "model_loaded": True}

@app.post("/predict")
async def predict_swing(file: UploadFile = File(...)):
    """
    Predict golf swing plane classification from video file
    
    Returns:
    - predicted_label: Classification result (on_plane, too_steep, too_flat)
    - confidence: Prediction confidence (0-1)
    - physics_insights: Key swing mechanics analysis
    """
    
    if not file.content_type.startswith('video/'):
        raise HTTPException(status_code=400, detail="File must be a video")
    
    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix='.mp4') as tmp_file:
        content = await file.read()
        tmp_file.write(content)
        tmp_path = tmp_file.name
    
    try:
        # Make prediction
        result = predict_with_physics_model(tmp_path)
        
        if result is None:
            raise HTTPException(status_code=400, detail="Failed to process video")
        
        # Format response
        response = {
            "predicted_label": result['predicted_label'],
            "confidence": float(result['confidence']),
            "confidence_gap": float(result['confidence_gap']),
            "all_probabilities": {k: float(v) for k, v in result['all_probabilities'].items()},
            "physics_insights": {
                "avg_plane_angle": float(result['physics_features'][0]),
                "plane_analysis": get_plane_analysis(result['physics_features'][0])
            },
            "extraction_status": result['extraction_status']
        }
        
        return JSONResponse(content=response)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")
    
    finally:
        # Clean up temporary file
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)

def get_plane_analysis(avg_plane_angle):
    """Get human-readable plane analysis"""
    if avg_plane_angle > 55:
        return "Swing plane is TOO STEEP (>55° from vertical)"
    elif avg_plane_angle < 35:
        return "Swing plane is TOO FLAT (<35° from vertical)"
    else:
        return "Swing plane is ON-PLANE (35-55° from vertical)"

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
